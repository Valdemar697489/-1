# KT11 – Генерация с RAG по существующему ТЗ

Простая реализация Retrieval-Augmented Generation (RAG).

## Файлы

- **md_to_vectors.py** — разбивает `tz.md` на блоки и векторизует.
- **vectorize_example_2.py** — ищет похожие блоки по запросу.
- **try_example.py** — отправляет запрос в модель с найденным контекстом.

## Использование

1. Создайте файл `tz.md` с текстом вашего ТЗ.
2. Установите зависимости:
   ```bash
   pip install -r requirements.txt
   ```
3. Сначала запустите векторизацию:
   ```bash
   python md_to_vectors.py
   ```
4. Затем попробуйте поиск похожих фрагментов:
   ```bash
   python vectorize_example_2.py
   ```
5. И наконец — генерацию ответа:
   ```bash
   python try_example.py
   ```

> 💡 Всё максимально просто, сделано в учебных целях.
