# md_to_vectors.py
# Скрипт для разбиения текста (например, ТЗ) на блоки и векторизации

import openai
import numpy as np
import faiss
from tqdm import tqdm

openai.api_key = "YOUR_API_KEY"  # замените на свой ключ

def read_text(filename):
    with open(filename, "r", encoding="utf-8") as f:
        return f.read()

def split_text(text, chunk_size=500):
    words = text.split()
    chunks = []
    for i in range(0, len(words), chunk_size):
        chunk = " ".join(words[i:i+chunk_size])
        chunks.append(chunk)
    return chunks

def embed_texts(texts):
    vectors = []
    for t in tqdm(texts, desc="Векторизация"):
        response = openai.embeddings.create(
            model="text-embedding-3-small",
            input=t
        )
        vec = np.array(response.data[0].embedding, dtype="float32")
        vectors.append(vec)
    return np.array(vectors)

if __name__ == "__main__":
    text = read_text("tz.md")  # исходный файл с ТЗ
    chunks = split_text(text)
    vectors = embed_texts(chunks)

    # сохраняем векторное пространство
    faiss_index = faiss.IndexFlatL2(vectors.shape[1])
    faiss_index.add(vectors)
    faiss.write_index(faiss_index, "vectors.index")

    print(f"✅ Векторизация завершена! Сохранено {len(vectors)} блоков.")
