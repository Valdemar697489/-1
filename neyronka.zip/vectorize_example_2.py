# vectorize_example_2.py
# Поиск похожих векторов по запросу

import openai
import numpy as np
import faiss

openai.api_key = "YOUR_API_KEY"

def get_vector(query):
    response = openai.embeddings.create(
        model="text-embedding-3-small",
        input=query
    )
    return np.array(response.data[0].embedding, dtype="float32")

def search_similar(query, top_k=3):
    index = faiss.read_index("vectors.index")
    vec = get_vector(query)
    vec = np.expand_dims(vec, axis=0)

    distances, indices = index.search(vec, top_k)
    print("🔍 Похожие блоки:")
    print("Индексы:", indices[0])
    print("Дистанции:", distances[0])

if __name__ == "__main__":
    q = input("Введите запрос: ")
    search_similar(q)
