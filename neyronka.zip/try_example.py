# try_example.py
# Отправка запроса в нейросеть с найденными контекстами

import openai
import numpy as np
import faiss

openai.api_key = "YOUR_API_KEY"

def get_vector(text):
    response = openai.embeddings.create(
        model="text-embedding-3-small",
        input=text
    )
    return np.array(response.data[0].embedding, dtype="float32")

def load_chunks():
    with open("tz.md", "r", encoding="utf-8") as f:
        text = f.read()
    return text.split("\n")

def find_similar_chunks(query, top_k=3):
    index = faiss.read_index("vectors.index")
    query_vec = get_vector(query)
    D, I = index.search(np.expand_dims(query_vec, 0), top_k)
    chunks = load_chunks()
    return [chunks[i] for i in I[0] if i < len(chunks)]

def ask_gpt(context, query):
    full_prompt = f"Контекст:\n{context}\n\nВопрос:\n{query}"
    response = openai.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": full_prompt}]
    )
    return response.choices[0].message.content

if __name__ == "__main__":
    q = input("Введите запрос: ")
    similar_chunks = find_similar_chunks(q)
    context = "\n".join(similar_chunks)
    answer = ask_gpt(context, q)
    print("\nОтвет нейросети:\n")
    print(answer)
